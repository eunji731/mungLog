package com.munglog.munglog_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MunglogBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MunglogBackendApplication.class, args);
	}

}
