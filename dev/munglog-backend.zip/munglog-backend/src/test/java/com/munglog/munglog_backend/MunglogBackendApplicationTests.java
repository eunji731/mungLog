package com.munglog.munglog_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MunglogBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
